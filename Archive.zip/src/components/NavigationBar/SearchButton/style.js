import {StyleSheet} from 'react-native';
import {Constants, Colors, Styles} from "@common"

export default StyleSheet.create({
  container: {

  },
  icon:{
    width:25,
    height:25,
    margin:10,
    resizeMode:'contain'
  }

});
