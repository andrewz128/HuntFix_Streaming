export default {
  //App: require('@images/ic_school.png'),
}
