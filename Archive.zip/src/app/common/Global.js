import _EventEmitter from 'EventEmitter';
export const EventEmitter = new _EventEmitter();
