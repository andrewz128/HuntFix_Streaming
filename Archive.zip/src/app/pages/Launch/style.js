import {StyleSheet} from 'react-native';
import {Constants, Colors, Styles} from "@common"

export default StyleSheet.create({
  container: {
    width:'100%',
    height:'100%',
    resizeMode:'cover'
  },

});
